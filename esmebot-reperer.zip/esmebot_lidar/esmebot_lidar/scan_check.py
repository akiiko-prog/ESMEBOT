"""Vérifie que le LiDAR publie un /scan exploitable.

Affiche toutes les 2 s : fréquence, nombre de points, % de mesures valides,
obstacle le plus proche et distance droit devant.

Usage :
  ros2 run esmebot_lidar scan_check
  ros2 run esmebot_lidar scan_check --ros-args -p topic:=/scan -p period:=1.0
"""

import math
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan


def analyse_scan(ranges, angle_min, angle_increment, range_min, range_max, front_half_width=math.radians(5)):
    """Calcule les statistiques d'un scan (fonction pure, testable sans ROS).

    Retourne un dict : n, valid, valid_pct, min_dist, min_angle_deg, front_dist.
    Les distances valent None quand aucune mesure valide n'est disponible.
    """
    n = len(ranges)
    valid = 0
    min_dist = None
    min_angle = None
    front = []
    for i, r in enumerate(ranges):
        if not math.isfinite(r) or r < range_min or r > range_max:
            continue
        valid += 1
        angle = angle_min + i * angle_increment
        if min_dist is None or r < min_dist:
            min_dist, min_angle = r, angle
        # angle ramené dans [-pi, pi] ; 0 rad = devant le robot
        a = math.atan2(math.sin(angle), math.cos(angle))
        if abs(a) <= front_half_width:
            front.append(r)
    return {
        'n': n,
        'valid': valid,
        'valid_pct': 100.0 * valid / n if n else 0.0,
        'min_dist': min_dist,
        'min_angle_deg': math.degrees(min_angle) if min_angle is not None else None,
        'front_dist': min(front) if front else None,
    }


def _fmt(value, unit='m'):
    return '   —   ' if value is None else f'{value:6.2f} {unit}'


class ScanCheck(Node):

    def __init__(self):
        super().__init__('scan_check')
        self.declare_parameter('topic', '/scan')
        self.declare_parameter('period', 2.0)
        topic = self.get_parameter('topic').value
        period = float(self.get_parameter('period').value)

        self.count = 0
        self.last = None
        self.window_start = time.monotonic()
        self.create_subscription(LaserScan, topic, self.on_scan, qos_profile_sensor_data)
        self.create_timer(period, self.report)
        self.get_logger().info(f'En attente de messages sur {topic} ...')

    def on_scan(self, msg):
        self.count += 1
        self.last = msg

    def report(self):
        now = time.monotonic()
        dt = now - self.window_start
        hz = self.count / dt if dt > 0 else 0.0
        self.count = 0
        self.window_start = now

        if self.last is None:
            self.get_logger().warn('Aucun scan reçu. Le driver tourne-t-il ? (ros2 topic list)')
            return

        m = self.last
        s = analyse_scan(m.ranges, m.angle_min, m.angle_increment, m.range_min, m.range_max)
        status = 'OK' if hz >= 5.0 and s['valid_pct'] >= 50.0 else 'A VERIFIER'
        angle = '' if s['min_angle_deg'] is None else f" à {s['min_angle_deg']:.0f}°"
        self.get_logger().info(
            f"[{status}] {hz:4.1f} Hz | frame={m.header.frame_id} | "
            f"{s['n']} pts, {s['valid_pct']:.0f}% valides | "
            f"plus proche {_fmt(s['min_dist'])}{angle} | devant {_fmt(s['front_dist'])}"
        )
        if hz == 0.0:
            self.get_logger().warn('Plus aucun scan depuis le dernier rapport.')


def main(args=None):
    rclpy.init(args=args)
    node = ScanCheck()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
