# esmebot_lidar : le LiDAR d'ESMEBOT

Ce paquet ROS 2 (Jazzy) fait tourner le **LiDAR LDROBOT D500** (capteur LD19 / STL-19P). Il publie trois choses :

| Sortie | Contenu | Utilisé par |
|---|---|---|
| `/scan` (`sensor_msgs/LaserScan`) | distances mesurées sur 360°, ~10 Hz | SLAM (slam_toolbox), Nav2 |
| TF `base_link → laser` | position du LiDAR sur le robot | SLAM, Nav2, RViz |
| `/pointcloud2d` | même chose en nuage de points | optionnel |

Il s'appuie sur le driver officiel [`ldlidar_ros2`](https://github.com/ldrobotSensorTeam/ldlidar_ros2), qu'il faut cloner à côté de ce paquet (voir plus bas).

---

## 1. Matériel

- LiDAR D500 et sa carte adaptateur USB (puce CP2102)
- Câble USB vers le Raspberry Pi 4 ou vers le PC
- Le LiDAR doit tourner dès qu'il est branché : il est alimenté par l'USB.

Pour vérifier que la carte est bien détectée :

```bash
lsusb | grep -i cp210        # doit afficher "Silicon Labs CP210x"
ls -l /dev/ttyUSB*           # en général /dev/ttyUSB0
```

> **Sous WSL (Windows)**, l'USB n'est pas visible par défaut. Il faut installer
> [usbipd-win](https://learn.microsoft.com/fr-fr/windows/wsl/connect-usb), puis taper
> dans un PowerShell administrateur : `usbipd list`, `usbipd bind --busid <ID>`,
> `usbipd attach --wsl --busid <ID>`.

---

## 2. Installation (une seule fois)

```bash
# Workspace ROS 2
mkdir -p ~/esmebot_ws/src
cd ~/esmebot_ws/src

# Le dépôt du projet (branche "reperer") et le driver LDROBOT
git clone -b reperer https://github.com/akiiko-prog/ESMEBOT.git
git clone https://github.com/ldrobotSensorTeam/ldlidar_ros2.git

# Dépendances, puis compilation
cd ~/esmebot_ws
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -y
colcon build --symlink-install
```

### Port série fixe et droits d'accès (règle udev)

Sans cette règle, le port peut changer de nom (`ttyUSB0`, `ttyUSB1`…) et il faut lancer `sudo chmod` à chaque branchement. Avec la règle, le LiDAR apparaît toujours sous `/dev/ldlidar` :

```bash
sudo cp ~/esmebot_ws/src/ESMEBOT/esmebot_lidar/udev/99-esmebot-lidar.rules /etc/udev/rules.d/
sudo udevadm control --reload-rules && sudo udevadm trigger
sudo usermod -aG dialout $USER     # puis se déconnecter / reconnecter
ls -l /dev/ldlidar                 # doit pointer vers ttyUSBx
```

> Sous WSL, udev ne fonctionne pas toujours. Dans ce cas, utilise directement
> `port:=/dev/ttyUSB0` et, si besoin, `sudo chmod 666 /dev/ttyUSB0`.

---

## 3. Utilisation

À faire dans chaque nouveau terminal (ou une fois pour toutes dans `~/.bashrc`) :

```bash
source /opt/ros/jazzy/setup.bash
source ~/esmebot_ws/install/setup.bash
```

Lancer le LiDAR :

```bash
ros2 launch esmebot_lidar lidar.launch.py              # LiDAR + TF
ros2 launch esmebot_lidar lidar.launch.py rviz:=true   # + visualisation RViz
ros2 launch esmebot_lidar lidar.launch.py port:=/dev/ttyUSB0
```

Arguments du launch :

| Argument | Défaut | Rôle |
|---|---|---|
| `port` | `/dev/ldlidar` | port série du LiDAR |
| `rviz` | `false` | ouvre RViz2 |
| `x`, `y`, `z` | `0`, `0`, `0.20` | position du LiDAR par rapport au centre du robot (m) |
| `yaw` | `0` | rotation du LiDAR (rad), si son « avant » ne regarde pas l'avant du robot |

> ⚠️ **`x`, `y`, `z` et `yaw` sont à mesurer sur le vrai robot.** Ces valeurs
> sont celles que le SLAM utilisera, donc il faut les transmettre à l'équipe navigation.

---

## 4. Vérifier que `/scan` est bon

Dans un 2ᵉ terminal, pendant que le launch tourne :

```bash
ros2 run esmebot_lidar scan_check
```

Exemple de sortie :

```
[OK] 10.0 Hz | frame=laser | 456 pts, 97% valides | plus proche   0.42 m à 87° | devant   2.31 m
```

Ce qu'il faut regarder :
- **~10 Hz** : c'est la fréquence normale du D500. Si tu lis 0 Hz, le driver ne publie rien.
- **% valides** : sous 50 % dans une pièce normale, quelque chose cache le LiDAR, ou alors il est sale.
- **devant** : pose un objet à 1 m devant le robot. La valeur doit être proche de 1 m. Sinon, le LiDAR est monté tourné et il faut corriger `yaw`.

Autres commandes ROS utiles :

```bash
ros2 topic hz /scan                   # fréquence
ros2 topic echo /scan --once          # un message complet
ros2 run tf2_ros tf2_echo base_link laser   # la transformée
```

Pour lancer les tests unitaires :

```bash
cd ~/esmebot_ws && colcon test --packages-select esmebot_lidar && colcon test-result --verbose
```

---

## 5. Dépannage

| Symptôme | Cause probable / solution |
|---|---|
| `open serial port failed` / `Permission denied` | droits sur le port : règle udev, ou `sudo chmod 666 /dev/ttyUSB0` |
| Le port n'existe pas | câble ou adaptateur ; sous WSL, `usbipd attach` à refaire après chaque branchement |
| Le LiDAR ne tourne pas | alimentation USB insuffisante : essayer un autre port ou un hub alimenté |
| `/scan` existe mais RViz n'affiche rien | dans RViz, *Fixed Frame* doit valoir `base_link` ; le topic `/scan` doit être en *Best Effort* |
| Le scan est en miroir | passer `laser_scan_dir` à `false` dans `config/lidar.yaml` |
| Un secteur est toujours « bouché » | un montant du châssis : activer `enable_angle_crop_func` et régler les angles |

---

## 6. Pour l'équipe SLAM / navigation

- Topic : **`/scan`**, repère **`laser`**, QoS *sensor data* (Best Effort)
- TF publiée : `base_link → laser` (statique). La TF `odom → base_link` doit venir de l'odométrie (moteurs), elle n'est pas fournie ici.
- Portée : 0,02 à 12 m, environ 450 points par tour, 10 Hz.
