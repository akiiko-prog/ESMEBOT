from glob import glob
import os

from setuptools import setup

package_name = 'esmebot_lidar'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'rviz'), glob('rviz/*.rviz')),
        (os.path.join('share', package_name, 'udev'), glob('udev/*.rules')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Ruben',
    maintainer_email='ruben.volu@gmail.com',
    description='LiDAR D500 (LD19) pour ESMEBOT : /scan + TF + vérification',
    license='MIT',
    entry_points={
        'console_scripts': [
            'scan_check = esmebot_lidar.scan_check:main',
        ],
    },
)
