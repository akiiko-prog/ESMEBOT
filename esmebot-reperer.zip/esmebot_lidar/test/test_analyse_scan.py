import math

from esmebot_lidar.scan_check import analyse_scan


def test_scan_vide():
    s = analyse_scan([], 0.0, 0.01, 0.02, 12.0)
    assert s['n'] == 0
    assert s['valid_pct'] == 0.0
    assert s['min_dist'] is None


def test_valeurs_invalides_ignorees():
    ranges = [float('inf'), float('nan'), 0.0, 13.0, 2.0]
    s = analyse_scan(ranges, 0.0, 0.1, 0.02, 12.0)
    assert s['valid'] == 1
    assert s['min_dist'] == 2.0


def test_distance_devant_et_plus_proche():
    # 360 points, 1 point par degré, en partant de -180°
    ranges = [5.0] * 360
    ranges[180] = 1.5   # 0° = devant
    ranges[270] = 0.8   # +90° = à gauche
    s = analyse_scan(ranges, -math.pi, math.radians(1), 0.02, 12.0)
    assert s['front_dist'] == 1.5
    assert s['min_dist'] == 0.8
    assert round(s['min_angle_deg']) == 90


def test_scan_0_a_360():
    # Le LD19 publie de 0 à 2π : l'angle 359° doit compter comme "devant"
    ranges = [5.0] * 360
    ranges[359] = 1.0
    s = analyse_scan(ranges, 0.0, math.radians(1), 0.02, 12.0)
    assert s['front_dist'] == 1.0
