"""Lance le LiDAR D500 (LD19) d'ESMEBOT.

Démarre :
  - le driver ldlidar_ros2 (publie /scan dans le repère "laser") ;
  - la transformée statique base_link -> laser (position du LiDAR sur le robot) ;
  - optionnellement RViz2 pour visualiser le scan.

Exemples :
  ros2 launch esmebot_lidar lidar.launch.py
  ros2 launch esmebot_lidar lidar.launch.py rviz:=true
  ros2 launch esmebot_lidar lidar.launch.py port:=/dev/ttyUSB0 z:=0.35
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    share = get_package_share_directory('esmebot_lidar')
    params_file = os.path.join(share, 'config', 'lidar.yaml')
    rviz_file = os.path.join(share, 'rviz', 'lidar.rviz')

    port = LaunchConfiguration('port')
    rviz = LaunchConfiguration('rviz')
    x = LaunchConfiguration('x')
    y = LaunchConfiguration('y')
    z = LaunchConfiguration('z')
    yaw = LaunchConfiguration('yaw')

    args = [
        DeclareLaunchArgument('port', default_value='/dev/ldlidar',
                              description='Port série du LiDAR (/dev/ldlidar ou /dev/ttyUSB0)'),
        DeclareLaunchArgument('rviz', default_value='false',
                              description='Ouvrir RViz2 pour visualiser /scan'),
        # Position du LiDAR par rapport au centre du robot (base_link), en mètres / radians.
        # À MESURER sur le vrai robot et à communiquer à l'équipe SLAM/navigation.
        DeclareLaunchArgument('x', default_value='0.0', description='Décalage avant (m)'),
        DeclareLaunchArgument('y', default_value='0.0', description='Décalage gauche (m)'),
        DeclareLaunchArgument('z', default_value='0.20', description='Hauteur (m)'),
        DeclareLaunchArgument('yaw', default_value='0.0',
                              description='Rotation autour de z (rad), si le LiDAR est tourné'),
    ]

    lidar_node = Node(
        package='ldlidar_ros2',
        executable='ldlidar_ros2_node',
        name='ldlidar',
        output='screen',
        parameters=[params_file, {'port_name': port}],
    )

    tf_node = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='base_link_to_laser',
        arguments=['--x', x, '--y', y, '--z', z, '--yaw', yaw,
                   '--frame-id', 'base_link', '--child-frame-id', 'laser'],
    )

    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_file],
        condition=IfCondition(rviz),
    )

    return LaunchDescription(args + [lidar_node, tf_node, rviz_node])
